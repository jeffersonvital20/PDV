/**
 * Angular 16 uses modern browsers; no additional polyfills required by default.
 */
