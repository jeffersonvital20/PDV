import { Injectable } from '@angular/core';
import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpResponse } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { delay, mergeMap } from 'rxjs/operators';

@Injectable()
export class FakeBackendInterceptor implements HttpInterceptor {
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const { url, method, body, headers } = req;

    return of(null).pipe(
      delay(400),
      mergeMap(handleRoute)
    );

    function handleRoute(): Observable<HttpEvent<any>> {
      if (url.endsWith('/auth/login') && method === 'POST') return authenticate();
      if (url.endsWith('/protected') && method === 'GET') return getProtected();
      return next.handle(req);
    }

    function authenticate(): Observable<HttpEvent<any>> {
      const { username, password } = body;
      if (username === 'admin' && password === 'admin') {
        const token = btoa(JSON.stringify({ sub: username, exp: Date.now() + 60*60*1000 }));
        return ok({ token, username });
      }
      return error('Credenciais inválidas');
    }

    function getProtected(): Observable<HttpEvent<any>> {
      if (!isLoggedIn()) return unauthorized();
      return ok({ data: 'Conteúdo protegido para usuários autenticados.' });
    }

    function ok(body?: any) {
      return of(new HttpResponse({ status: 200, body }));
    }

    function unauthorized() {
      return throwError(() => ({ status: 401, error: { message: 'Não autorizado' } }));
    }

    function error(message: string) {
      return throwError(() => ({ status: 400, error: { message } }));
    }

    function isLoggedIn(): boolean {
      const authHeader = headers.get('Authorization') || '';
      return authHeader.startsWith('Bearer ');
    }
  }
}
