export const environment = {
  production: true,
  apiUrl: 'https://example.com/api' // ajuste para sua API real
};
